create database DB_RodoFacil
go
use DB_RodoFacil
go
create table Departamento (id int primary key IDENTITY (1,1), 
					  nome varchar(max))
go
create table Produto (id int primary key IDENTITY (1,1), 
					  nome varchar(max),
					  preco DECIMAL(10,2),
					  idDepartamento int foreign key references Departamento (id),
					  altura DECIMAL(10,2),
					  largura DECIMAL(10,2),
					  comprimento DECIMAL(10,2),
					  estoque int null)
go
create table Venda (id int primary key IDENTITY (1,1),
					valor decimal (10, 2),
					data_venda varchar(max),
					)
go
create table ItemVenda (IdVenda int foreign key references Venda (id),
						IdProduto int foreign key references Produto (id),
						quantidade int)
go

create trigger DeleteDep ON departamento instead of
	 delete 
AS 
BEGIN
	declare @id int
	set @id = (select id from deleted)
   delete from Produto where Produto.idDepartamento = @id
   delete  from Departamento where id = @id
   commit
END
GO
