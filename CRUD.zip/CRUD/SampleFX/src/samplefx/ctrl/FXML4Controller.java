/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package samplefx.ctrl;

import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;

public class FXML4Controller implements Initializable {
	@FXML
	Button btnSalvar = new Button(); 
	
	@FXML
	TextField txtNome = new TextField();
	
	@FXML
	Button btnCancelar = new Button(); 
	
	DepartamentoDao pdao = new DepartamentoDao();
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }    
    
    public void InserirDepartamento (ActionEvent event) {
    	Departamento p = new Departamento();
    	p.setNome(txtNome.getText());
    	pdao.InserirDepartamento(p);
    	showAlertWithHeaderText();
    	LimpaCampos();
    }
    
    private void showAlertWithHeaderText() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Departamento Inserido");
        alert.setHeaderText("Departamento Inserido com Sucesso!");
        alert.setContentText("O Departamento foi inserido na base de dados!");
 
        alert.showAndWait();
    }
    
    public void Cancelar (ActionEvent event){
    	LimpaCampos();
    }
    
    public void LimpaCampos() {
    	txtNome.clear();
    	txtNome.requestFocus();
    }
    
}