/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package samplefx.ctrl;
import java.net.URL;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;

public class FXML2Controller implements Initializable {
	
	@FXML
	Button btnRegistrar = new Button(); 
	
	@FXML
	Button btnDeletar = new Button(); 
	
	@FXML
	Button btnAdicionar = new Button(); 
	
	@FXML
	TableView<ProdAux> tbItens = new TableView();
	
	@FXML
	Button btnCancelar = new Button(); 
	
	@FXML
	TextField txtQuantidade = new TextField();
	
	@FXML
	ComboBox<Object> cbProdutos = new ComboBox<Object>();
	
	@FXML
	Label lblValor = new Label();
	
	ProdutoDao pdao = new ProdutoDao();
	VendaDao vdao = new VendaDao();
	ItemVendaDao ivdao = new ItemVendaDao();
	
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    	TableColumn colunaNome = new TableColumn("Produto");
		colunaNome.setCellValueFactory(new PropertyValueFactory<>("nome"));

		TableColumn colunaQuantidade = new TableColumn("Quantidade");
		colunaQuantidade.setCellValueFactory(new PropertyValueFactory<>("quantidade"));
		
		tbItens.getColumns().clear();
		tbItens.getColumns().addAll(colunaNome, colunaQuantidade);
		colunaNome.setPrefWidth(535);
        
    	try {
			pdao.ConsultaTudo(cbProdutos);
		} catch (Exception e) { //troca por SQLException
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    public void AddTable () throws SQLException {
		ProdAux p = new ProdAux();
		p.setNome(cbProdutos.getValue().toString());
		p.setQuantidade(Integer.parseInt(txtQuantidade.getText()));
		tbItens.getItems().add(p);
		cbProdutos.setValue("");
		cbProdutos.requestFocus();
		txtQuantidade.setText("");
	}
	
	public void DeleteTable () throws SQLException {
		
		ObservableList<ProdAux> selecionado, todos; 
		todos = tbItens.getItems();
		selecionado = tbItens.getSelectionModel().getSelectedItems();
		selecionado.forEach(todos::remove);
	}
	
	public void AtualizarEstoque () throws SQLException {
		
		ArrayList<String> values = new ArrayList<>();
	    ObservableList<TableColumn<ProdAux, ?>> columns = tbItens.getColumns();

	    for (ProdAux row : tbItens.getItems()) {
	    	pdao.AtualizarEstoque(row.getNome(), row.getQuantidade());
	    }
	    LimpaCampos();
	    ExibirMensagem();

	}

	public void LimpaCampos () {
		cbProdutos.setValue("");
		txtQuantidade.setText("");
		tbItens.getItems().clear();
		cbProdutos.requestFocus();
		}

	private void ExibirMensagem() {
		Alert alert = new Alert(AlertType.INFORMATION);
		alert.setTitle("Estoque atualizado!");
		alert.setHeaderText("Estoque atualizado com Sucesso!");
		alert.setContentText("Os produtos foram inseridos no controle de estoque!");
		alert.showAndWait();
	}
    
}
