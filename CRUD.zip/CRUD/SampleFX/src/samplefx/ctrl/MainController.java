package samplefx.ctrl;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.animation.FadeTransition;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.util.Duration;

public class MainController implements Initializable {
	@FXML
	Button btnRegistrar = new Button(); 
	
	@FXML
	Button btnDeletar = new Button(); 
	
	@FXML
	Button btnAdicionar = new Button(); 
	
	@FXML
	Button btnCancelar = new Button(); 
	
	@FXML
	TextField txtQuantidade = new TextField();
	
	@FXML
	ComboBox<Object> cbProdutos = new ComboBox<Object>();
	
	@FXML
	GridPane GridProdutos = new GridPane();
	
	@FXML
	Label lblValor = new Label();
	
	ProdutoDao pdao = new ProdutoDao();
	
    @FXML
    private Button btnMenuBar;

    @FXML
    private Button openFrm2;

    @FXML
    private Button openFrm3;
    
    @FXML
    private Button openFrm4;
    
    @FXML
    private Button openFrm5;
    
    @FXML
    private Button openFrm6;

    @FXML
    private VBox dataPane;

    public void setDataPane(Node node) {
        dataPane.getChildren().setAll(node);
    }

    public VBox fadeAnimate(String url) throws IOException {
        VBox v = (VBox) FXMLLoader.load(getClass().getResource(url));
        FadeTransition ft = new FadeTransition(Duration.millis(1500));
        ft.setNode(v);
        ft.setFromValue(0.1);
        ft.setToValue(1);
        ft.setCycleCount(1);
        ft.setAutoReverse(false);
        ft.play();
        return v;
    }

    public void loadPane(ActionEvent event) throws IOException {
        setDataPane(fadeAnimate("/samplefx/view/FXML1.fxml"));
    }

    public void loadPane2(ActionEvent event) throws IOException {
        setDataPane(fadeAnimate("/samplefx/view/FXML2.fxml"));
    }

    public void loadPane3(ActionEvent event) throws IOException {
        setDataPane(fadeAnimate("/samplefx/view/FXML3.fxml"));
    }
    
    public void loadPane4(ActionEvent event) throws IOException {
        setDataPane(fadeAnimate("/samplefx/view/FXML4.fxml"));
    }
    
    public void loadPane5(ActionEvent event) throws IOException {
        setDataPane(fadeAnimate("/samplefx/view/FXML5.fxml"));
    }
    
    public void loadPane6(ActionEvent event) throws IOException {
        setDataPane(fadeAnimate("/samplefx/view/FXML6.fxml"));
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    	try {
    		setDataPane(fadeAnimate("/samplefx/view/FXML1.fxml"));
    		
		} catch (Exception e) { //troca por SQLException
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
}
