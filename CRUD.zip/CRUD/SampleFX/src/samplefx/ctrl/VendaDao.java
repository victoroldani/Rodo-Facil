package samplefx.ctrl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class VendaDao {
	
	private static Connection connection;
	
	public VendaDao() {
		connection = DbUtil.getConnection();
	}
	
	public void InserirVenda (Venda v) { //mudar para incluir
		
		try {
			
			PreparedStatement preparedStatement = connection.prepareStatement(
					"INSERT INTO Venda (data_venda, valor) VALUES (?, ?)");
			
			preparedStatement.setString(1, v.getData());
			preparedStatement.setDouble(2, v.getValor());
			preparedStatement.execute();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	public int ResgataMaiorID () throws SQLException {
		int ID = 0;
		try {
			Statement st =  connection.createStatement();
			ResultSet rs = st.executeQuery("Select Max(id) from Venda");
			
			while (rs.next()) {
			      int id = rs.getInt(1);
			      return id;
			    }
			

        } catch (SQLException ex) {
            System.err.println("Error"+ex);
        }
		return ID;
	}
}
