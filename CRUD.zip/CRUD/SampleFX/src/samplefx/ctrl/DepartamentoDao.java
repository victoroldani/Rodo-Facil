package samplefx.ctrl;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ComboBox;

public class DepartamentoDao {

	//TODO: Add
	//TODO: Update
	//TODO: Delete
	
	private static Connection connection;
	
	public DepartamentoDao() {
		connection = DbUtil.getConnection();
	}
	
	public void InserirDepartamento(Departamento d) { //mudar para incluir
		
		try {
			
			PreparedStatement preparedStatement = connection.prepareStatement(
					"INSERT INTO Departamento (nome) VALUES (?)");
			
			preparedStatement.setString(1, d.getNome());

			preparedStatement.execute();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	}
	
	public static void ConsultaTudo(ComboBox<Object> cb) throws SQLException { //mudar para consultarTudo
        try {
            
        	ObservableList<Object> Lista = FXCollections.observableArrayList();
            // Execute query and store result in a resultset
            ResultSet rs = connection.createStatement().executeQuery("SELECT * FROM Departamento;");
            while (rs.next()) {
                //get string from db,whichever way 
            	Lista.add(new String(rs.getString("nome")));
            }
            cb.setItems(null);
            cb.setItems(Lista);

        } catch (SQLException ex) {
            System.err.println("Error"+ex);
        }
	}
	
	public int ConsultaID (String nome) throws SQLException {
		int ID = 0;
		try {
			Statement st =  connection.createStatement();
			ResultSet rs = st.executeQuery("SELECT * from Departamento where nome = '" + nome + "'");
			
			while (rs.next()) {
			      int id = rs.getInt(1);
			      return id;
			    }
			

        } catch (SQLException ex) {
            System.err.println("Error"+ex);
        }
		return ID;
	}
	
	public void AlterarDepartamento (Departamento d, String novo) throws SQLException {
			int id = ConsultaID(d.getNome());
			try {
				PreparedStatement preparedStatement = connection.prepareStatement(
						"update departamento set nome = ? where id = ?");
				
				preparedStatement.setString(1, novo);
				preparedStatement.setInt(2, id);
				preparedStatement.execute();
				
			} catch (Exception e) {
				e.printStackTrace();
			}
	}
	
	public void ExcluirDepartamento (Departamento d) throws SQLException {
		int id = ConsultaID(d.getNome());
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(
					"delete from departamento where id = ?");
			
			preparedStatement.setInt(1, id);
			preparedStatement.execute();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}