package samplefx.ctrl;

import java.io.Serializable;

public class Produto  implements Serializable {
	
	/**
	 * 
	 */
	public Produto (String nome, double preco, int altura, int largura, int comprimento, String departamento){
		this.nome = nome;
		this.preco = preco;
		this.altura = altura; 
		this.largura = largura;
		this.comprimento = comprimento;
		this.departamento = departamento;
	}
	
	private static final long serialVersionUID = 1L;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		if (nome.length() > 0)
			this.nome = nome;
	}
	public double getPreco() {
		return preco;
	}
	public void setPreco(double preco) {
		if (preco > 0)
			this.preco = preco;
	}
	public int getAltura() {
		return altura;
	}
	public void setAltura(int altura) {
		if (altura > 0)
			this.altura = altura;
	}
	public int getLargura() {
		return largura;
	}
	public void setLargura(int largura) {
		if (largura > 0)
			this.largura = largura;
	}
	public int getComprimento() {
		return comprimento;
	}
	public void setComprimento(int comprimento) {
		if (comprimento > 0)
			this.comprimento = comprimento;
	}
	public String getDepartamento() {
		return departamento;
	}
	public void setDepartamento(String departamento) {
		if (nome.length() > 0)
			this.departamento = departamento;
	}
	int id;
	String nome;
	double preco;
	int altura;
	int largura;
	int comprimento;
	String departamento;
	
}
