/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package samplefx.ctrl;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;

public class FXML3Controller implements Initializable {
	@FXML
	Button btnSalvar = new Button(); 
	
	@FXML
	TextField txtNome = new TextField();
	
	@FXML
	TextField txtpreco = new TextField();
	
	@FXML
	ComboBox cbDepartamento = new ComboBox();
	
	@FXML
	TextField txtAltura = new TextField();
	
	@FXML
	TextField txtLargura = new TextField();
	
	@FXML
	TextField txtComprimento = new TextField();
	
	@FXML
	Button btnCancelar = new Button(); 
    /**
     * Initializes the controller class.
     */
	
	ProdutoDao pdao = new ProdutoDao();
	DepartamentoDao ddao = new DepartamentoDao();
	
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    	try {
    		//System.out.println("teste");
			ddao.ConsultaTudo(cbDepartamento);
    		
		} catch (Exception e) { //troca por SQLException
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    public void InserirProduto (ActionEvent event) {
    	//(String nome, double preco, int altura, int largura, int comprimento)
    	Produto p = new Produto(txtNome.getText(), Double.parseDouble(txtpreco.getText()), Integer.parseInt(txtAltura.getText()), Integer.parseInt(txtLargura.getText()), Integer.parseInt(txtComprimento.getText()), String.valueOf(cbDepartamento.getValue().toString()));
    	pdao.addProduto(p);
    	LimpaCampos();
    	showAlertWithHeaderText();
    }
    
    public void Cancelar (ActionEvent event){
    	//(String nome, double preco, int altura, int largura, int comprimento)
    	LimpaCampos();
    }
    
    private void showAlertWithHeaderText() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Produto Inserido");
        alert.setHeaderText("Produto Inserido com Sucesso!");
        alert.setContentText("O Produto foi inserido na base de dados!");
 
        alert.showAndWait();
    }
    
    public void LimpaCampos() {
    	txtNome.clear();
    	txtpreco.clear();
    	txtAltura.clear();
    	txtLargura.clear();
    	txtComprimento.clear();
    	cbDepartamento.setValue("");
    	txtNome.requestFocus();
    }
    
}
