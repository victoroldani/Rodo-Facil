/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package samplefx.ctrl;

import java.net.URL;
import java.sql.SQLException;
import java.util.Optional;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;

public class FXML6Controller implements Initializable {

	@FXML
	TextField txtLargura = new TextField();
	
	@FXML
	ComboBox cbDepartamento = new ComboBox();
	
	@FXML
	Button btnSalvarProd = new Button();
	
	@FXML
	Button btnExcluirProd = new Button();
	
	@FXML
	Button btnExcluirDep = new Button();
	
	@FXML
	Button btnAltDep = new Button();
	
	@FXML
	ComboBox cbProduto_alt = new ComboBox();
	
	@FXML
	Button btnCancelarDep = new Button();
	
	@FXML
	TextField txtDepNome_alt = new TextField();
	
	@FXML
	ComboBox cbDepartamento_alt = new ComboBox();
	
	@FXML
	TextField txtPreco = new TextField();
	
	@FXML
	TextField txtAltura = new TextField();
	
	@FXML
	TextField txtComprimento = new TextField();
	
	@FXML
	Button btnCancelarProd = new Button();
	
	ProdutoDao pdao = new ProdutoDao();
	DepartamentoDao ddao = new DepartamentoDao(); 
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    	try {
    		//System.out.println("teste");
			pdao.ConsultaTudo(cbProduto_alt);
			ddao.ConsultaTudo(cbDepartamento_alt);
			ddao.ConsultaTudo(cbDepartamento);
			
		} catch (Exception e) { //troca por SQLException
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }  

    public void AlterarProduto (ActionEvent event) {
    	//(String nome, double preco, int altura, int largura, int comprimento)
    	Produto p = new Produto("", 0,0,0,0, "");
    	
    	p.setNome(cbProduto_alt.getValue().toString());
    	
    	if (txtPreco.getText().length() != 0) {
    		p.setPreco(Double.parseDouble(txtPreco.getText()));
    	}
    	else {
    		p.setPreco(0);
    	}
    	
    	if (txtAltura.getText().length() != 0) {
    		p.setAltura(Integer.parseInt(txtAltura.getText()));
    	}
    	else {
    		p.setAltura(0);
    	}
    	
    	if (txtLargura.getText().length() != 0) {
    		p.setLargura(Integer.parseInt(txtLargura.getText()));
    	}
    	else {
    		p.setLargura(0);
    	}
    	
    	if (txtComprimento.getText().length() != 0) {
    		p.setComprimento(Integer.parseInt(txtComprimento.getText()));
    	}
    	else {
    		p.setComprimento(0);
    	}
    	
    	if (cbDepartamento.getSelectionModel().getSelectedItem() != null) {
    		p.setDepartamento(cbDepartamento.getValue().toString());
    	}
    	else {
    		p.setDepartamento("");
    	}
    	
    	pdao.AlterarProduto(p);
    	AlertaAlterarProd();
    	CancelarProd();
    }
    
    public void AlterarDepartamento (ActionEvent event) throws SQLException {
    	//(String nome, double preco, int altura, int largura, int comprimento)
    	Departamento d = new Departamento();
    	if (cbDepartamento_alt.getSelectionModel().getSelectedItem() != null) {
    		d.setNome(cbDepartamento_alt.getValue().toString());
    		ddao.AlterarDepartamento(d, txtDepNome_alt.getText());
    		AlertaAlterarDep();
    		CancelarDep();
    	}
    }
    
    public void CancelarProd () {
    	cbProduto_alt.setValue("");
    	txtPreco.clear();
    	txtAltura.clear();
    	txtLargura.clear();
    	txtComprimento.clear();
    	cbDepartamento.setValue("");
    	cbProduto_alt.requestFocus();
    }
    
    public void CancelarDep () {
    	txtDepNome_alt.clear();
    	cbDepartamento_alt.setValue("");
    	cbDepartamento_alt.requestFocus();
    }
    
    public void ExcluirDepartamento (ActionEvent event) throws SQLException {
    	showConfirmationDep();
    }
    
    public void ExcluirProduto (ActionEvent event) throws SQLException {
    	
    	showConfirmationProd();
    }
    
    private void showConfirmationProd() {
    	Produto p = new Produto("", 0,0,0,0, "");
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Deletar Produto");
        alert.setHeaderText("Tem certeza de que deseja excluir este produto?");
        alert.setContentText("Por favor, confirme a opera��o");
        
        // option != null.
        Optional<ButtonType> option = alert.showAndWait();
   
        if (option.get() == null) {
           
        } else if (option.get() == ButtonType.OK) {
        	
        	if (cbProduto_alt.getSelectionModel().getSelectedItem() != null) {

				 p.setNome(cbProduto_alt.getValue().toString());
	    		 try {
					pdao.ExcluirProduto(p);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	    		 showAlertWithHeaderTextProd();
	    		 CancelarProd();
			 }
           
        } else if (option.get() == ButtonType.CANCEL) {
        	CancelarProd();
        } else {
           
        }
     }
    
    private void showConfirmationDep() throws SQLException {
    	Departamento d = new Departamento();
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Deletar Produto");
        alert.setHeaderText("Tem certeza de que deseja excluir este departamento?");
        alert.setContentText("Os produtos associados a ele tamb�m ser�o exclu�dos!");
        
        // option != null.
        Optional<ButtonType> option = alert.showAndWait();
   
        if (option.get() == null) {
           
        } else if (option.get() == ButtonType.OK) {
        	
        	if (cbDepartamento_alt.getSelectionModel().getSelectedItem() != null) {

        		if (cbDepartamento_alt.getSelectionModel().getSelectedItem() != null) {
            		d.setNome(cbDepartamento_alt.getValue().toString());
            		ddao.ExcluirDepartamento(d);
            		showAlertWithHeaderTextDep();
            		CancelarDep();
			 }
        	}
        } else if (option.get() == ButtonType.CANCEL) {
        	CancelarDep(); 
        }
    } 
       
    private void AlertaAlterarProd() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Altera��o");
        alert.setHeaderText("Produto Alterado.");
        alert.setContentText("Os Dados do Produto foram alterados com Sucesso!");
        alert.showAndWait();
    }
    
    private void AlertaAlterarDep() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Altera��o");
        alert.setHeaderText("Departamento Alterado.");
        alert.setContentText("Os Dados do Departamento foram alterados com Sucesso!");
        alert.showAndWait();
    }
    
    private void showAlertWithHeaderTextProd() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Exclus�o");
        alert.setHeaderText("Produto exclu�do.");
        alert.setContentText("O Produto foi exclu�do da Base de Dados com Sucesso!");
        alert.showAndWait();
    }
    
    private void showAlertWithHeaderTextDep() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Exclus�o");
        alert.setHeaderText("Departamento exclu�do.");
        alert.setContentText("O Departamento e os produtos associados � ele foram exclu�dos da Base de Dados com Sucesso!");
        alert.showAndWait();
    }
}