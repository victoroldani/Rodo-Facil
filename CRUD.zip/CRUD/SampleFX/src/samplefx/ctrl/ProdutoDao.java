package samplefx.ctrl;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.control.ComboBox;

public class ProdutoDao {

	//TODO: Add
	//TODO: Update
	//TODO: Delete
	
	private static Connection connection;
	DepartamentoDao ddao = new DepartamentoDao();
	
	public ProdutoDao() {
		connection = DbUtil.getConnection();
	}
	
	public int ConsultaID (String nome) throws SQLException {
		int ID = 0;
		try {
			Statement st =  connection.createStatement();
			ResultSet rs = st.executeQuery("SELECT * from produto where nome = '" + nome + "'");
			
			while (rs.next()) {
			      int id = rs.getInt(1);
			      return id;
			    }
			

        } catch (SQLException ex) {
            System.err.println("Error"+ex);
        }
		return ID;
	}
	
	public void addProduto(Produto p) {
		
		try {
			
			PreparedStatement preparedStatement = connection.prepareStatement(
					"INSERT INTO produto (nome, preco, altura, largura, comprimento, idDepartamento, estoque) VALUES (?, ?, ?, ?, ?, ?, ?)");
			
			preparedStatement.setString(1, p.getNome());
			preparedStatement.setDouble(2, p.getPreco());
			preparedStatement.setInt(3, p.getAltura());
			preparedStatement.setInt(4, p.getLargura());
			preparedStatement.setInt(5, p.getComprimento());
			preparedStatement.setInt(6, 0);
			
			int idDep =  ddao.ConsultaID(p.getDepartamento());
			
			preparedStatement.setInt(6, idDep);
			preparedStatement.execute();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
		
	} //addPeople
	
	public static void ConsultaTudo(ComboBox<Object> cb) throws SQLException {
        try {
            
        	ObservableList<Object> Lista = FXCollections.observableArrayList();
            // Execute query and store result in a resultset
            ResultSet rs = connection.createStatement().executeQuery("SELECT * FROM Produto;");
            while (rs.next()) {
            	Lista.add(new String(rs.getString("nome")));
            }
            cb.setItems(null);
            cb.setItems(Lista);

        } catch (SQLException ex) {
            System.err.println("Error"+ex);
        }
		
	}
	
	public double ConsultaPreco (String nome) throws SQLException {
		double preco = 0;
		try {
			Statement st =  connection.createStatement();
			ResultSet rs = st.executeQuery("SELECT preco from produto where nome = '" + nome + "'");
			
			while (rs.next()) {
			      double id = rs.getDouble(1);
			      return id;
			    }
			
        } catch (SQLException ex) {
            System.err.println("Error"+ex);
        }
		return preco;
	}
	
	public int ConsultaEstoque (String nome) throws SQLException {
		int estoque = 0;
		try {
			Statement st =  connection.createStatement();
			ResultSet rs = st.executeQuery("SELECT estoque from produto where nome = '" + nome + "'");
			
			while (rs.next()) {
			      estoque = rs.getInt(1);
			      return estoque;
			    }
			
        } catch (SQLException ex) {
            System.err.println("Error"+ex);
        }
		return estoque;
	}
	
	public void AtualizarEstoque (String nome, int quantidade) {
		try {
			
			PreparedStatement preparedStatement = connection.prepareStatement(
					"update produto set estoque = ? where nome = ?");
			
			int estoque_atual = ConsultaEstoque(nome);
			
			preparedStatement.setInt(1, estoque_atual + quantidade);
			preparedStatement.setString(2,nome);
			preparedStatement.execute();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public void AlterarProduto (Produto p) { 
		if (p.getAltura() != 0) {
			try {
				
				PreparedStatement preparedStatement = connection.prepareStatement(
						"update produto set altura = ? where nome = ?");
				
				preparedStatement.setDouble(1,p.getAltura());
				preparedStatement.setString(2, p.getNome());
				preparedStatement.execute();
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (p.getLargura() != 0) {
			try {
				
				PreparedStatement preparedStatement = connection.prepareStatement(
						"update produto set largura = ? where nome = ?");
				
				preparedStatement.setDouble(1,p.getLargura());
				preparedStatement.setString(2, p.getNome());
				preparedStatement.execute();
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (p.getComprimento() != 0) {
			try {
				
				PreparedStatement preparedStatement = connection.prepareStatement(
						"update produto set comprimento = ? where nome = ?");
				
				preparedStatement.setDouble(1,p.getComprimento());
				preparedStatement.setString(2, p.getNome());
				preparedStatement.execute();
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (p.getDepartamento().length() != 0) {
			try {
				
				PreparedStatement preparedStatement = connection.prepareStatement(
						"update produto set idDepartamento = ? where nome = ?");
				
				int idDep =  ddao.ConsultaID(p.getDepartamento());
				preparedStatement.setInt(1,idDep);
				
				preparedStatement.setString(2, p.getNome());
				preparedStatement.execute();
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		if (p.getPreco() != 0) {
			try {
				
				PreparedStatement preparedStatement = connection.prepareStatement(
						"update produto set preco = ? where nome = ?");
				
				preparedStatement.setDouble(1,p.getPreco());
				preparedStatement.setString(2, p.getNome());
				preparedStatement.execute();
				
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}
	
	public void ExcluirProduto (Produto p) throws SQLException {
		
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(
					"delete from produto where nome = ?");
			
			preparedStatement.setString(1, p.getNome());
			preparedStatement.execute();
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}//addPeople
}
