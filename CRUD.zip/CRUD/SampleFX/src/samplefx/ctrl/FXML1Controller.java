
package samplefx.ctrl;

import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.ResourceBundle;

import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableRow;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.GridPane;

public class FXML1Controller implements Initializable {
	@FXML
	Button btnRegistrar = new Button(); 
	
	@FXML
	Button btnDeletar = new Button(); 
	
	@FXML
	Button btnAdicionar = new Button(); 
	
	@FXML
	TableView<ProdAux> tbItens = new TableView();
	
	@FXML
	Button btnCancelar = new Button(); 
	
	@FXML
	TextField txtQuantidade = new TextField();
	
	@FXML
	ComboBox<Object> cbProdutos = new ComboBox<Object>();
	
	@FXML
	Label lblValor = new Label();
	
	ProdutoDao pdao = new ProdutoDao();
	VendaDao vdao = new VendaDao();
	ItemVendaDao ivdao = new ItemVendaDao();
	
	double valor_total = 0;
	
    /**
     * Initializes the controller class.
     */
	
	@Override
    public void initialize(URL url, ResourceBundle rb) {
		
		lblValor.setText( String.valueOf(valor_total));
		
		TableColumn colunaNome = new TableColumn("Produto");
		colunaNome.setCellValueFactory(new PropertyValueFactory<>("nome"));

		TableColumn colunaQuantidade = new TableColumn("Quantidade");
		colunaQuantidade.setCellValueFactory(new PropertyValueFactory<>("quantidade"));
		
		tbItens.getColumns().clear();
		tbItens.getColumns().addAll(colunaNome, colunaQuantidade);
		colunaNome.setPrefWidth(535);
        
        //tbItens.getColumns().addAll(colunaProduto, colunaQuantidade);
        
    	try {
			pdao.ConsultaTudo(cbProdutos);
		} catch (Exception e) { //troca por SQLException
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
	
	public void AddTable () throws SQLException {
		ProdAux p = new ProdAux();
		p.setNome(cbProdutos.getValue().toString());
		p.setQuantidade(Integer.parseInt(txtQuantidade.getText()));
		tbItens.getItems().add(p);
		cbProdutos.setValue("");
		cbProdutos.requestFocus();
		txtQuantidade.setText("");
		
		valor_total += (pdao.ConsultaPreco(p.getNome()) * p.getQuantidade());
		lblValor.setText( String.valueOf(valor_total));
	}
	
	public void DeleteTable () throws SQLException {
		
		ObservableList<ProdAux> selecionado, todos; 
		todos = tbItens.getItems();
		selecionado = tbItens.getSelectionModel().getSelectedItems();
		
		for(ProdAux aux: selecionado){
			valor_total -= (pdao.ConsultaPreco(aux.getNome()) * aux.getQuantidade());
			}
		
		selecionado.forEach(todos::remove);
		lblValor.setText( String.valueOf(valor_total));
	}
	
	public void RegistrarVenda () throws SQLException {
		
		Venda v = new Venda();
		Date d = new java.util.Date();
		String data = String.valueOf(d);
	    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	    
		v.setData(sdf.format(d));
		v.setValor(valor_total);
		vdao.InserirVenda(v);
		
		ArrayList<String> values = new ArrayList<>();
	    ObservableList<TableColumn<ProdAux, ?>> columns = tbItens.getColumns();

	    for (ProdAux row : tbItens.getItems()) {
	    	
	    	ItemVenda iv = new ItemVenda();
	    	String nome = row.getNome();
	    	
	    	iv.setIdProduto(pdao.ConsultaID(nome));
	    	iv.setIdVenda(vdao.ResgataMaiorID());
	    	iv.setQuantidade(row.getQuantidade());
	    	
	    	ivdao.InserirItemVenda(iv);
	    }
	    LimpaCampos();
	    ExibirMensagem();
	}
	
	public void LimpaCampos () {
		cbProdutos.setValue("");
		txtQuantidade.setText("");
		tbItens.getItems().clear();
		valor_total = 0;
		lblValor.setText(String.valueOf(valor_total));
		cbProdutos.requestFocus();
	}
	
	private void ExibirMensagem() {
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("Venda cadastrada");
        alert.setHeaderText("Venda cadastrada com Sucesso!");
        alert.setContentText("A venda foi inserido na base de dados!");
        alert.showAndWait();
    }
}
